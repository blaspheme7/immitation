package listeners;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import dao.MemberDaoTest;

@WebListener
public class ContextLoaderTest implements ServletContextListener {
	
	@Override
	public void contextInitialized(ServletContextEvent event) {
		
		Connection conn=null;
		ServletContext sc=event.getServletContext();
		MemberDaoTest memberDao=new MemberDaoTest();
		
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			conn=DriverManager.getConnection(	"jdbc:mysql://localhost:3306/basicjsp",
												"jspid", "jsppass");
			memberDao.setConnection(conn);
			sc.setAttribute("memberDao", memberDao);
			
			System.out.println("test_context_loader");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		
	}

}
