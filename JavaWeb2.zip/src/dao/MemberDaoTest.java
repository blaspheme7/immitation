package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import vo.Member;

public class MemberDaoTest {
	
	Connection conn;
	
	public void setConnection(Connection conn){
		
		this.conn=conn;
		
	}
	
	public void memberInsert(Member member) {
		
		PreparedStatement pstmt = null;
		try {
			pstmt=conn.prepareStatement("insert into member(email,name,number,password) values (?,?,?,?)");
			pstmt.setString(1, member.getEmail());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getNumber());
			pstmt.setString(4, member.getPassword());
			pstmt.executeUpdate();
		} catch (Exception e) {
			
		} finally {
			try { if(pstmt!=null){ pstmt.close(); } } catch (Exception e){};
		}
	}
	
	public ArrayList<Member> importMemberList() {
		ArrayList<Member> members=new ArrayList<Member>();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
		try {
			stmt=conn.prepareStatement("select * from member");
			rs=stmt.executeQuery();
			//stmt=conn.createStatement();
			//rs=stmt.executeQuery("select * from member");
			
			while(rs.next()) {
				members.add(new Member().setEmail(rs.getString("email"))
										.setName(rs.getString("name"))
										.setPassword(rs.getString("password"))
										.setNumber(rs.getString("number")));
			}
		} catch (Exception e) {
			
		}
		
		return members;
	}
}