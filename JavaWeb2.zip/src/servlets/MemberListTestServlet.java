package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import dao.MemberDaoTest;
import vo.Member;

@WebServlet("/test/memberlist")
public class MemberListTestServlet extends GenericServlet {
	
	@Override
	public void service (ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		//Connection conn=null;
		//Statement stmt=null;
		//ResultSet rs=null;
			
		System.out.println("test.memberlist.service");
		ServletContext sc=this.getServletContext();
		MemberDaoTest memberDao=(MemberDaoTest) sc.getAttribute("memberDao");
		
		try {
			
			
			//DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			//conn=DriverManager.getConnection(	"jdbc:mysql://localhost:3306/basicjsp",
			//									"jspid", "jsppass");
			//stmt=conn.createStatement();
			//rs=stmt.executeQuery("select * from member order by name asc");
			response.setContentType("text/html; charset=UTF-8");
			
			//ArrayList<Member> members = new ArrayList<Member>();
			ArrayList<Member> members=memberDao.importMemberList();
			
			//while(rs.next()) {
			//	
			//	members.add(new Member().setName(rs.getString("name"))
			//							.setEmail(rs.getString("email"))
			//							.setPassword(rs.getString("password"))
			//							.setNumber(rs.getString("number")));
			//	
			//}
			
			request.setAttribute("members", members);
			//PrintWriter out=response.getWriter();
			//out.println("<html><head><title>회원목록</title></head>");
			//out.println("<body><h1>회원목록</h1>");
			
			//while(rs.next()) {
			//	out.println(rs.getString("name")+" , "+
			//				rs.getString("number")+" , "+
			//				rs.getString("email")+"<br>");
			//}
			
			//out.println("</body></html>");
			
			//RequestDispatcher rd = request.getRequestDispatcher("/MemberListTest.jsp");
			//rd.include(request, response);
			String viewUrl="/MemberListTest.jsp";
			request.setAttribute("viewUrl", viewUrl);
			
		} catch (Exception e) {
			throw new ServletException(e);
		} finally {
			//try { if(rs!=null) rs.close();} catch(Exception e) {}
			//try { if(stmt!=null) stmt.close();} catch(Exception e) {}
			//try { if(conn!=null) conn.close();} catch(Exception e) {}
		}
	}
}
