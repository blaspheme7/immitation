package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MemberDaoTest;
import vo.Member;


@WebServlet("/test/memberadd")
public class MemberAddTestServlet extends HttpServlet {
	
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		String viewUrl="/MemberAddTest.jsp";
		//RequestDispatcher rd=request.getRequestDispatcher("/MemberAddTest.jsp");
		request.setAttribute("viewUrl", viewUrl);
		//rd.include(request, response);		
	}
	
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		ServletContext sc=this.getServletContext();
		MemberDaoTest memberDao=(MemberDaoTest)sc.getAttribute("memberDao");
		//Member member=new Member()	.setName(request.getParameter("name"))
		//							.setEmail(request.getParameter("email"))
		//							.setPassword(request.getParameter("password"))
		//							.setNumber(request.getParameter("number"));
		Member member=(Member) request.getAttribute("member");
		memberDao.memberInsert(member);
		request.setAttribute("viewUrl", "redirect:memberlist.test");
		
		//Connection conn=null;	
		//PreparedStatement stmt=null;
		
		
		try {
			// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			// conn=DriverManager.getConnection(	"jdbc:mysql://localhost:3306/basicjsp",
			// 										"jspid", "jsppass");
			//conn=(Connection)request.getAttribute("conn");
			//stmt=conn.prepareStatement("insert into member(name,email,number,password) values (?,?,?,?)");
			//stmt.setString(1,request.getParameter("name"));
			//stmt.setString(2,request.getParameter("email"));
			//stmt.setString(3,request.getParameter("number"));
			//stmt.setString(4,request.getParameter("password"));
			//stmt.executeUpdate();
			
			//response.sendRedirect("/JavaWeb/test/memberlist");
			
			
		} catch (Exception e) {
			
		} finally {
			//try {if(conn!=null) conn.close(); } catch (Exception e) {};
			//try {if(stmt!=null) stmt.close(); } catch (Exception e) {};
		}
			
	}
	
}
