package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vo.Member;

@WebServlet("*.test")
public class DispatcherTestServlet extends HttpServlet {
	
	@Override
	protected void service (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String servletPath=request.getServletPath();
		response.setContentType("text/html; charset=UTF-8");
		try {
			
			String pageControllerPath=servletPath.substring(0, servletPath.length()-5);
			System.out.println("pageControllerPath="+pageControllerPath);
			
			if("/test/memberadd".equals(pageControllerPath)) {
				System.out.println("request.getParameter("+"email"+")="+request.getParameter("email"));
				if(request.getParameter("email")!=null) {
					System.out.println("if_if_memberadd");
					Member member = new Member();
					member	.setEmail(request.getParameter("email"))
							.setName(request.getParameter("name"))
							.setNumber(request.getParameter("number"))
							.setPassword(request.getParameter("password"));
					request.setAttribute("member", member);
				}	
			}
			
			RequestDispatcher rd=request.getRequestDispatcher(pageControllerPath);
			rd.include(request, response);
			
			String viewUrl=(String)request.getAttribute("viewUrl");
			if(viewUrl.startsWith("redirect:")) {
				
				response.setContentType("text/html; charset=UTF-8");
				response.sendRedirect(viewUrl.substring(9));
			}
			
			else {
				rd=request.getRequestDispatcher(viewUrl);
				response.setContentType("text/html; charset=UTF-8");
				rd.include(request, response);
			}					
		} catch(Exception e){
			
			e.printStackTrace();
			request.setAttribute("error", e);
			RequestDispatcher rd=request.getRequestDispatcher("/error.jsp");
			rd.forward(request, response);
			
		}
	}
}
